# homework 1 
def get_bus_info_go(bus_id):
    """
    回傳指定 bus_id 的所有車站 ID 列表 (按照順序)
    :param bus_id: 巴士的 ID
    :return: 車站 ID 列表
    """
    # 模擬資料，請替換為實際的資料檢索邏輯
    bus_stop_data = {
        "M25305": ["stop_id1", "stop_id2", "stop_id3"],
        "0161000900": ["stop_id4", "stop_id5", "stop_id6"],
        "0161001500": ["stop_id7", "stop_id8", "stop_id9"]
    }

    return bus_stop_data.get(bus_id, [])